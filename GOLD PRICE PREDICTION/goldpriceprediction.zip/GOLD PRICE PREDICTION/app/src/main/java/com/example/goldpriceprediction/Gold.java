package com.example.goldpriceprediction;

public class Gold {

    public String Spx;
    public String Uso;
    public String Slv;
    public String Cur;

}
